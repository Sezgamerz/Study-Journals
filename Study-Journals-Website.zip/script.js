document.getElementById("storyForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const name = document.getElementById("name").value || "Anonymous";
  const story = document.getElementById("story").value;
  document.getElementById("confirmation").innerText = "Thanks, " + name + "! Your story has been saved (not really, just a demo 😉).";
  this.reset();
});
